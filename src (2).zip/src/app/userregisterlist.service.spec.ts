import { TestBed } from '@angular/core/testing';

import { UserregisterlistService } from './userregisterlist.service';

describe('UserregisterlistService', () => {
  let service: UserregisterlistService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserregisterlistService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
