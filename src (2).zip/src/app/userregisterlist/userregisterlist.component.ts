import { Component, OnInit } from '@angular/core';
import { Register } from '../register';
import { RegisterService } from '../register.service';
declare var $: any;

@Component({
  selector: 'app-userregisterlist',
  templateUrl: './userregisterlist.component.html',
  styleUrls: ['./userregisterlist.component.css']
})
export class UserregisterlistComponent implements OnInit {

  registers!: Register[];
  constructor(private registerService: RegisterService) { }
   //this.projectService.getProjectList().subscribe();

  ngOnInit(){
    this.getUserList();
    $(document).ready(function() {
      setTimeout(function() {
        $('#kb_listing_table').dataTable();  
        $('.kb-listing-data-table').show();          
      }, 200);
  });

}  
 
getUserList() {
  this.registerService.getUserRegisterList().subscribe((response: any)=>{
    this.registers = response;
 });
}
registerDeleted(userId: Number){
  if(confirm("Are you sure want to delete this record?")) {    
      this.registerService.deleteUser(userId).subscribe((response: any)=>{  
    });      
    location.reload();
  }
  else
  {
    location.reload();
  }
}
}