export class Register {
    userId !: Number;
    firstname!: String;
    lastname!: String;
    email!:String;
    pwd!:String;
    rpwd!:String;

}
