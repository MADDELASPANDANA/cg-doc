package day.three;

import java.util.Scanner;

public class CustomerDemo {

	public static void main(String[] args) {
		BankApp bankApp = new BankApp();
		Scanner sc = new Scanner(System.in);
		int choice;
		do{
			System.out.println("1. Add Customer ");
			System.out.println("2. Display All Customers");
			System.out.println("3. Display Customer By Id : ");
			System.out.println("4. Deposit : ");
			System.out.println("5. Withdraw : ");
			System.out.println("6. Exit");
			System.out.println("Enter your choice : ");
			choice = sc.nextInt();
			switch(choice){
			case 1: System.out.println("Enter fisrt name : ");
			String firstName = sc.next();
			System.out.println("Enter last name : ");
			String lastName = sc.next();
			System.out.println("Enter Ur address ");
			System.out.println("Enter door no : ");
			String doorNo = sc.next();
			System.out.println("Enter street : ");
			String street = sc.next();
			System.out.println("Enter city : ");
			String city = sc.next();
			System.out.println("Enter balance amount : ");
			double balance = sc.nextDouble();
			int id = bankApp.addCustomer(new Customer(firstName,lastName,new Address(doorNo,street,city),balance));
			System.out.println("Customer added successfully..id is "+id);
			break;
			case 2: 
				Customer[] customers = bankApp.displayAllCustomers();
				for(int i = 0; i < BankApp.index; i++){
					System.out.println("Id : " + customers[i].getId());
					System.out.println("First Name : " + customers[i].getFirstName());
					System.out.println("Last Name : " + customers[i].getLastName());
					System.out.println("Ur Address is : ");
					System.out.println("Door No : " + customers[i].getAddress().getDoorNo());
					System.out.println("Street : " + customers[i].getAddress().getStreet());
					System.out.println("City : " + customers[i].getAddress().getCity());
					System.out.println("Balance: " + customers[i].getBalance());
				}
				break;
			}

		}while(choice < 5);
	}

}
